//
//  ViewController.swift
//  Calc
//
//  Created by Emily Denham on 1/27/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

